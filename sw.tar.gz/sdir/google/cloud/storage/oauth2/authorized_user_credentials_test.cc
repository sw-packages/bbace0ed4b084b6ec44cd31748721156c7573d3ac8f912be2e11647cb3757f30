// Copyright 2018 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "google/cloud/storage/oauth2/authorized_user_credentials.h"
#include "google/cloud/storage/oauth2/credential_constants.h"
#include "google/cloud/storage/testing/mock_http_request.h"
#include "google/cloud/testing_util/mock_fake_clock.h"
#include "google/cloud/testing_util/mock_http_payload.h"
#include "google/cloud/testing_util/mock_rest_client.h"
#include "google/cloud/testing_util/mock_rest_response.h"
#include "google/cloud/testing_util/status_matchers.h"
#include <gmock/gmock.h>
#include <nlohmann/json.hpp>
#include <cstring>

namespace google {
namespace cloud {
namespace storage {
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_BEGIN
namespace oauth2 {

// Define a helper to test the specialization.
struct AuthorizedUserCredentialsTester {
  static StatusOr<std::string> Header(
      AuthorizedUserCredentials<>& tested,
      std::chrono::system_clock::time_point tp) {
    return tested.AuthorizationHeaderForTesting(tp);
  }

  static AuthorizedUserCredentials<> MakeAuthorizedUserCredentials(
      google::cloud::oauth2_internal::AuthorizedUserCredentialsInfo info,
      oauth2_internal::HttpClientFactory factory) {
    return AuthorizedUserCredentials<>(std::move(info), Options{},
                                       std::move(factory));
  }
};

namespace {

using ::google::cloud::storage::internal::HttpResponse;
using ::google::cloud::storage::testing::MockHttpRequest;
using ::google::cloud::storage::testing::MockHttpRequestBuilder;
using ::google::cloud::testing_util::FakeClock;
using ::google::cloud::testing_util::IsOk;
using ::google::cloud::testing_util::IsOkAndHolds;
using ::google::cloud::testing_util::MakeMockHttpPayloadSuccess;
using ::google::cloud::testing_util::MockRestClient;
using ::google::cloud::testing_util::MockRestResponse;
using ::google::cloud::testing_util::StatusIs;
using ::testing::_;
using ::testing::AllOf;
using ::testing::An;
using ::testing::AtLeast;
using ::testing::ByMove;
using ::testing::HasSubstr;
using ::testing::Not;
using ::testing::Return;
using ::testing::StrEq;

class AuthorizedUserCredentialsTest : public ::testing::Test {
 protected:
  void SetUp() override {
    MockHttpRequestBuilder::mock_ =
        std::make_shared<MockHttpRequestBuilder::Impl>();
  }
  void TearDown() override { MockHttpRequestBuilder::mock_.reset(); }
};

/// @test Verify that we can create credentials from a JWT string.
TEST_F(AuthorizedUserCredentialsTest, Simple) {
  std::string response = R"""({
    "token_type": "Type",
    "access_token": "access-token-value",
    "id_token": "id-token-value",
    "expires_in": 1234
})""";
  auto mock_request = std::make_shared<MockHttpRequest::Impl>();
  EXPECT_CALL(*mock_request, MakeRequest)
      .WillOnce([response](std::string const& payload) {
        EXPECT_THAT(payload, HasSubstr("grant_type=refresh_token"));
        EXPECT_THAT(payload, HasSubstr("client_id=a-client-id.example.com"));
        EXPECT_THAT(payload, HasSubstr("client_secret=a-123456ABCDEF"));
        EXPECT_THAT(payload, HasSubstr("refresh_token=1/THETOKEN"));
        return HttpResponse{200, response, {}};
      });

  auto mock_builder = MockHttpRequestBuilder::mock_;
  EXPECT_CALL(*mock_builder,
              Constructor(StrEq("https://oauth2.googleapis.com/token"), _, _))
      .Times(1);
  EXPECT_CALL(*mock_builder, BuildRequest()).WillOnce([mock_request]() {
    MockHttpRequest result;
    result.mock = mock_request;
    return result;
  });
  EXPECT_CALL(*mock_builder, MakeEscapedString)
      .WillRepeatedly([](std::string const& s) {
        auto t = std::unique_ptr<char[]>(new char[s.size() + 1]);
        std::copy(s.begin(), s.end(), t.get());
        t[s.size()] = '\0';
        return t;
      });

  std::string config = R"""({
      "client_id": "a-client-id.example.com",
      "client_secret": "a-123456ABCDEF",
      "refresh_token": "1/THETOKEN",
      "type": "magic_type"
})""";

  auto info = ParseAuthorizedUserCredentials(config, "test");
  ASSERT_STATUS_OK(info);
  AuthorizedUserCredentials<MockHttpRequestBuilder> credentials(*info);
  EXPECT_EQ("Authorization: Type access-token-value",
            credentials.AuthorizationHeader().value());
}

/// @test Verify that we can refresh service account credentials.
TEST_F(AuthorizedUserCredentialsTest, Refresh) {
  // Prepare two responses, the first one is used but becomes immediately
  // expired, resulting in another refresh next time the caller tries to get
  // an authorization header.
  std::string r1 = R"""({
    "token_type": "Type",
    "access_token": "access-token-r1",
    "id_token": "id-token-value",
    "expires_in": 0
})""";
  std::string r2 = R"""({
    "token_type": "Type",
    "access_token": "access-token-r2",
    "id_token": "id-token-value",
    "expires_in": 1000
})""";

  // Now setup the builder to return those responses.
  auto mock_builder = MockHttpRequestBuilder::mock_;
  EXPECT_CALL(*mock_builder, BuildRequest())
      .WillOnce([&] {
        MockHttpRequest request;
        EXPECT_CALL(*request.mock, MakeRequest)
            .WillOnce(Return(HttpResponse{200, r1, {}}));
        return request;
      })
      .WillOnce([&] {
        MockHttpRequest request;
        EXPECT_CALL(*request.mock, MakeRequest)
            .WillOnce(Return(HttpResponse{200, r2, {}}));
        return request;
      });
  EXPECT_CALL(*mock_builder, Constructor(GoogleOAuthRefreshEndpoint(), _, _))
      .Times(AtLeast(1));
  EXPECT_CALL(*mock_builder, MakeEscapedString)
      .WillRepeatedly([](std::string const& s) {
        auto t = std::unique_ptr<char[]>(new char[s.size() + 1]);
        std::copy(s.begin(), s.end(), t.get());
        t[s.size()] = '\0';
        return t;
      });

  std::string config = R"""({
      "client_id": "a-client-id.example.com",
      "client_secret": "a-123456ABCDEF",
      "refresh_token": "1/THETOKEN",
      "type": "magic_type"
})""";
  auto info = ParseAuthorizedUserCredentials(config, "test");
  ASSERT_STATUS_OK(info);
  AuthorizedUserCredentials<MockHttpRequestBuilder> credentials(*info);
  EXPECT_EQ("Authorization: Type access-token-r1",
            credentials.AuthorizationHeader().value());
  EXPECT_EQ("Authorization: Type access-token-r2",
            credentials.AuthorizationHeader().value());
  EXPECT_EQ("Authorization: Type access-token-r2",
            credentials.AuthorizationHeader().value());
}

/// @test Mock a failed refresh response.
TEST_F(AuthorizedUserCredentialsTest, FailedRefresh) {
  // Now setup the builder to return those responses.
  auto mock_builder = MockHttpRequestBuilder::mock_;
  EXPECT_CALL(*mock_builder, BuildRequest())
      .WillOnce([] {
        MockHttpRequest request;
        EXPECT_CALL(*request.mock, MakeRequest)
            .WillOnce(Return(Status(StatusCode::kAborted, "Fake Curl error")));
        return request;
      })
      .WillOnce([] {
        MockHttpRequest request;
        EXPECT_CALL(*request.mock, MakeRequest)
            .WillOnce(Return(HttpResponse{400, "", {}}));
        return request;
      });
  EXPECT_CALL(*mock_builder, Constructor(GoogleOAuthRefreshEndpoint(), _, _))
      .Times(AtLeast(1));
  EXPECT_CALL(*mock_builder, MakeEscapedString(An<std::string const&>()))
      .WillRepeatedly([](std::string const& s) {
        auto t = std::unique_ptr<char[]>(new char[s.size() + 1]);
        std::copy(s.begin(), s.end(), t.get());
        t[s.size()] = '\0';
        return t;
      });

  std::string config = R"""({
      "client_id": "a-client-id.example.com",
      "client_secret": "a-123456ABCDEF",
      "refresh_token": "1/THETOKEN",
      "type": "magic_type"
})""";
  auto info = ParseAuthorizedUserCredentials(config, "test");
  ASSERT_STATUS_OK(info);
  AuthorizedUserCredentials<MockHttpRequestBuilder> credentials(*info);
  // Response 1
  auto status = credentials.AuthorizationHeader();
  EXPECT_THAT(status, StatusIs(StatusCode::kAborted));
  // Response 2
  status = credentials.AuthorizationHeader();
  EXPECT_THAT(status, Not(IsOk()));
}

/// @test Verify that the options are used in the constructor.
TEST_F(AuthorizedUserCredentialsTest, UsesCARootsInfo) {
  // Now setup the builder to return a valid response.
  auto mock_builder = MockHttpRequestBuilder::mock_;
  EXPECT_CALL(*mock_builder, BuildRequest()).WillOnce([&] {
    MockHttpRequest request;
    nlohmann::json response{{"token_type", "Mock-Type"},
                            {"access_token", "fake-token"},
                            {"id_token", "fake-id-token-value"},
                            {"expires_in", 3600}};
    EXPECT_CALL(*request.mock, MakeRequest)
        .WillOnce(Return(HttpResponse{200, response.dump(), {}}));
    return request;
  });

  // This is the key check in this test, verify the constructor is called with
  // the right parameters.
  auto const cainfo = std::string{"fake-cainfo-path-aka-roots-pem"};
  EXPECT_CALL(*mock_builder, Constructor(GoogleOAuthRefreshEndpoint(),
                                         absl::make_optional(cainfo), _))
      .Times(AtLeast(1));
  EXPECT_CALL(*mock_builder, MakeEscapedString(An<std::string const&>()))
      .WillRepeatedly([](std::string const& s) {
        auto t = std::unique_ptr<char[]>(new char[s.size() + 1]);
        std::copy(s.begin(), s.end(), t.get());
        t[s.size()] = '\0';
        return t;
      });

  std::string config = R"""({
      "client_id": "a-client-id.example.com",
      "client_secret": "a-123456ABCDEF",
      "refresh_token": "1/THETOKEN",
      "type": "magic_type"
})""";
  auto info = ParseAuthorizedUserCredentials(config, "test");
  ASSERT_STATUS_OK(info);
  AuthorizedUserCredentials<MockHttpRequestBuilder> credentials(
      *info, ChannelOptions().set_ssl_root_path(cainfo));
  EXPECT_EQ("Authorization: Mock-Type fake-token",
            credentials.AuthorizationHeader().value());
}

/// @test Verify that parsing an authorized user account JSON string works.
TEST_F(AuthorizedUserCredentialsTest, ParseSimple) {
  std::string config = R"""({
      "client_id": "a-client-id.example.com",
      "client_secret": "a-123456ABCDEF",
      "refresh_token": "1/THETOKEN",
      "token_uri": "https://oauth2.googleapis.com/test_endpoint",
      "type": "magic_type"
})""";

  auto actual =
      ParseAuthorizedUserCredentials(config, "test-data", "unused-uri");
  ASSERT_STATUS_OK(actual);
  EXPECT_EQ("a-client-id.example.com", actual->client_id);
  EXPECT_EQ("a-123456ABCDEF", actual->client_secret);
  EXPECT_EQ("1/THETOKEN", actual->refresh_token);
  EXPECT_EQ("https://oauth2.googleapis.com/test_endpoint", actual->token_uri);
}

/// @test Verify that parsing an authorized user account JSON string works.
TEST_F(AuthorizedUserCredentialsTest, ParseUsesExplicitDefaultTokenUri) {
  // No token_uri attribute here, so the default passed below should be used.
  std::string config = R"""({
      "client_id": "a-client-id.example.com",
      "client_secret": "a-123456ABCDEF",
      "refresh_token": "1/THETOKEN",
      "type": "magic_type"
})""";

  auto actual = ParseAuthorizedUserCredentials(
      config, "test-data", "https://oauth2.googleapis.com/test_endpoint");
  ASSERT_STATUS_OK(actual);
  EXPECT_EQ("a-client-id.example.com", actual->client_id);
  EXPECT_EQ("a-123456ABCDEF", actual->client_secret);
  EXPECT_EQ("1/THETOKEN", actual->refresh_token);
  EXPECT_EQ("https://oauth2.googleapis.com/test_endpoint", actual->token_uri);
}

/// @test Verify that parsing an authorized user account JSON string works.
TEST_F(AuthorizedUserCredentialsTest, ParseUsesImplicitDefaultTokenUri) {
  // No token_uri attribute here.
  std::string config = R"""({
      "client_id": "a-client-id.example.com",
      "client_secret": "a-123456ABCDEF",
      "refresh_token": "1/THETOKEN",
      "type": "magic_type"
})""";

  // No token_uri passed in here, either.
  auto actual = ParseAuthorizedUserCredentials(config, "test-data");
  ASSERT_STATUS_OK(actual);
  EXPECT_EQ("a-client-id.example.com", actual->client_id);
  EXPECT_EQ("a-123456ABCDEF", actual->client_secret);
  EXPECT_EQ("1/THETOKEN", actual->refresh_token);
  EXPECT_EQ(std::string(GoogleOAuthRefreshEndpoint()), actual->token_uri);
}

/// @test Verify that invalid contents result in a readable error.
TEST_F(AuthorizedUserCredentialsTest, ParseInvalidContentsFails) {
  EXPECT_THAT(ParseAuthorizedUserCredentials(
                  R"""( not-a-valid-json-string })""", "test-as-a-source"),
              StatusIs(Not(StatusCode::kOk),
                       AllOf(HasSubstr("Invalid AuthorizedUserCredentials"),
                             HasSubstr("test-as-a-source"))));

  EXPECT_THAT(ParseAuthorizedUserCredentials(
                  R"""("valid-json-but-not-an-object")""", "test-as-a-source"),
              StatusIs(Not(StatusCode::kOk),
                       AllOf(HasSubstr("Invalid AuthorizedUserCredentials"),
                             HasSubstr("test-as-a-source"))));
}

/// @test Parsing a service account JSON string should detect empty fields.
TEST_F(AuthorizedUserCredentialsTest, ParseEmptyFieldFails) {
  std::string contents = R"""({
      "client_id": "a-client-id.example.com",
      "client_secret": "a-123456ABCDEF",
      "refresh_token": "1/THETOKEN",
      "type": "magic_type"
})""";

  for (auto const& field : {"client_id", "client_secret", "refresh_token"}) {
    auto json = nlohmann::json::parse(contents);
    json[field] = "";
    auto info = ParseAuthorizedUserCredentials(json.dump(), "test-data");
    EXPECT_THAT(info,
                StatusIs(Not(StatusCode::kOk),
                         AllOf(HasSubstr(field), HasSubstr(" field is empty"),
                               HasSubstr("test-data"))));
  }
}

/// @test Parsing a service account JSON string should detect missing fields.
TEST_F(AuthorizedUserCredentialsTest, ParseMissingFieldFails) {
  std::string contents = R"""({
      "client_id": "a-client-id.example.com",
      "client_secret": "a-123456ABCDEF",
      "refresh_token": "1/THETOKEN",
      "type": "magic_type"
})""";

  for (auto const& field : {"client_id", "client_secret", "refresh_token"}) {
    auto json = nlohmann::json::parse(contents);
    json.erase(field);
    auto info = ParseAuthorizedUserCredentials(json.dump(), "test-data");
    EXPECT_THAT(info,
                StatusIs(Not(StatusCode::kOk),
                         AllOf(HasSubstr(field), HasSubstr(" field is missing"),
                               HasSubstr("test-data"))));
  }
}

/// @test Parsing an invalid refresh response results in failure.
TEST_F(AuthorizedUserCredentialsTest, ParseAuthorizedUserRefreshResponseError) {
  std::string r1 = R"""({})""";
  // Does not have access_token.
  std::string r2 = R"""({
    "token_type": "Type",
    "id_token": "id-token-value",
    "expires_in": 1000
})""";

  FakeClock::reset_clock(1000);
  auto status = ParseAuthorizedUserRefreshResponse(HttpResponse{400, r1, {}},
                                                   FakeClock::now());
  EXPECT_THAT(status,
              StatusIs(StatusCode::kInvalidArgument,
                       HasSubstr("Could not find all required fields")));

  status = ParseAuthorizedUserRefreshResponse(HttpResponse{400, r2, {}},
                                              FakeClock::now());
  EXPECT_THAT(status,
              StatusIs(StatusCode::kInvalidArgument,
                       HasSubstr("Could not find all required fields")));

  EXPECT_THAT(ParseAuthorizedUserRefreshResponse(
                  HttpResponse{400, R"js("valid-json-but-not-an-object)js", {}},
                  FakeClock::now()),
              StatusIs(StatusCode::kInvalidArgument,
                       HasSubstr("Could not find all required fields")));
}

/// @test Parsing a refresh response yields a TemporaryToken.
TEST_F(AuthorizedUserCredentialsTest, ParseAuthorizedUserRefreshResponse) {
  std::string r1 = R"""({
    "token_type": "Type",
    "access_token": "access-token-r1",
    "id_token": "id-token-value",
    "expires_in": 1000
})""";

  auto expires_in = 1000;
  FakeClock::reset_clock(2000);
  auto status = ParseAuthorizedUserRefreshResponse(HttpResponse{200, r1, {}},
                                                   FakeClock::now());
  EXPECT_STATUS_OK(status);
  auto token = *status;
  EXPECT_EQ(
      std::chrono::time_point_cast<std::chrono::seconds>(token.expiration_time)
          .time_since_epoch()
          .count(),
      FakeClock::now_value_ + expires_in);
  EXPECT_EQ(token.token, "Authorization: Type access-token-r1");
}

TEST_F(AuthorizedUserCredentialsTest, Caching) {
  // We need to mock the Security Token Service or this would be an
  // integration test that requires a valid user account.
  auto make_mock_client = [](std::string const& payload) {
    auto response = std::make_unique<MockRestResponse>();
    EXPECT_CALL(*response, StatusCode)
        .WillRepeatedly(
            Return(google::cloud::rest_internal::HttpStatusCode::kOk));
    EXPECT_CALL(std::move(*response), ExtractPayload)
        .WillOnce(Return(ByMove(MakeMockHttpPayloadSuccess(payload))));
    auto mock = std::make_unique<MockRestClient>();
    using PostPayloadType = std::vector<std::pair<std::string, std::string>>;
    EXPECT_CALL(*mock, Post(_, _, An<PostPayloadType const&>()))
        .WillOnce(Return(ByMove(std::unique_ptr<rest_internal::RestResponse>(
            std::move(response)))));
    return std::unique_ptr<rest_internal::RestClient>(std::move(mock));
  };

  auto constexpr kPayload1 = R"js({
    "access_token": "access-token-1", "id_token": "id-token-1",
    "token_type": "Bearer", "expires_in": 3600})js";
  auto constexpr kPayload2 = R"js({
    "access_token": "access-token-2", "id_token": "id-token-2",
    "token_type": "Bearer", "expires_in": 3600})js";

  using MockHttpClientFactory =
      ::testing::MockFunction<std::unique_ptr<rest_internal::RestClient>(
          Options const&)>;
  MockHttpClientFactory mock_factory;
  EXPECT_CALL(mock_factory, Call)
      .WillOnce(Return(ByMove(make_mock_client(kPayload1))))
      .WillOnce(Return(ByMove(make_mock_client(kPayload2))));

  auto tested = AuthorizedUserCredentialsTester::MakeAuthorizedUserCredentials(
      oauth2_internal::AuthorizedUserCredentialsInfo{},
      mock_factory.AsStdFunction());
  auto const tp = std::chrono::system_clock::now();
  auto initial = AuthorizedUserCredentialsTester::Header(tested, tp);
  ASSERT_STATUS_OK(initial);

  auto cached = AuthorizedUserCredentialsTester::Header(
      tested, tp + std::chrono::seconds(30));
  EXPECT_THAT(cached, IsOkAndHolds(*initial));

  cached = AuthorizedUserCredentialsTester::Header(
      tested, tp + std::chrono::seconds(300));
  EXPECT_THAT(cached, IsOkAndHolds(*initial));

  auto uncached = AuthorizedUserCredentialsTester::Header(
      tested, tp + std::chrono::hours(2));
  ASSERT_STATUS_OK(uncached);
  EXPECT_NE(*initial, *uncached);
}

}  // namespace
}  // namespace oauth2
GOOGLE_CLOUD_CPP_INLINE_NAMESPACE_END
}  // namespace storage
}  // namespace cloud
}  // namespace google
